<head>
	<title>Project Proposal</title>
	<link rel="stylesheet" type="text/css" href="main.css">
	<link rel="stylesheet" type="text/css" href="gallery.css">
	<link rel="stylesheet" type="text/css" href="updates.css">
	<link rel="stylesheet" type="text/css" href="footer.css"><!--BEWARE Footer @ registform1.html got different css styling-->
</head>
<body>
	<div id="wrapper">
		<header>
		<!--NAVBAR-->
			<nav>
				<ul>
				<a href="index.html">
				<img src="logo.jpg" alt="AH_Logo" width="60" height="60" style="float: left; padding-top: 20px; padding-left: 20px; ">
				</a>
					<li><a href="index.html">Home</a></li>
					<li><a href="#">Discuss</a></li>
					<li><a href="#">Review</a></li>
					<li><a href="#">New Animes</a></li>
					<li><a href="#">Fan Animes</a></li>
					<div id="foruser">
					<a href="registerform1.html">Register</a> /
					<a href="login.html">Login</a></div>
					</ul>
					<div id="search">
					<form action="#">
					<input type="search" name="searchbar" placeholder="Seach Here...">
					<input type="submit" value="Search">
				
					</form>
					</div>

			</nav>
			<!--NAVBAR-End-->
		</header>
		<!--BODYCONTENT-AnimeGallery-->
		<div class="gallery" align="center">
			<h3>Popular Animes</h3>
			<div class="thumbnails">
	<img onmouseover="preview.src=img1.src" name="img1" src="photogallery/naruto.jpg" alt="Naruto" />
	<img onmouseover="preview.src=img1.src" name="img1" src="photogallery/deathnote.jpg" alt="Deathnote" />

	<img onmouseover="preview.src=img2.src" name="img2" src="photogallery/bleach.jpg" alt="Bleach" />
	<img onmouseover="preview.src=img3.src" name="img3" src="photogallery/gintama.jpg" alt="Gintama" />
	<img onmouseover="preview.src=img4.src" name="img4" src="photogallery/dragonball.jpg" alt="Dragonballz" />
	<img onmouseover="preview.src=img5.src" name="img5" src="photogallery/onepiece.png" alt="Onepiece" />
	<img onmouseover="preview.src=img5.src" name="img5" src="photogallery/fairytail.png" alt="Fairytail" />
	<img onmouseover="preview.src=img5.src" name="img5" src="photogallery/metalchemist.jpg" alt="FullMetal Alchemist" />
</div>
<!--BODYCONTENT-AnimeGallery End-->
</div>